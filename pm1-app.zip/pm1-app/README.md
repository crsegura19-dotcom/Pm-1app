# PM1 — Primer Movimiento

Sistema de intervención conductual. Transforma evitación en acción real.

## Despliegue en Vercel (5 minutos)

### 1. Sube el proyecto a GitHub
```bash
git init
git add .
git commit -m "PM1 v1.0"
git remote add origin https://github.com/TU_USUARIO/pm1-app.git
git push -u origin main
```

### 2. Importa en Vercel
1. Ve a [vercel.com](https://vercel.com) → New Project
2. Importa tu repositorio de GitHub
3. En **Environment Variables** añade:
   - `ANTHROPIC_API_KEY` = tu API key de Anthropic
4. Click **Deploy**

### 3. Obtén tu URL
Vercel te da una URL tipo `pm1-app.vercel.app`. Esa es la URL que compartes.

---

## Desarrollo local

```bash
npm install
cp .env.example .env.local
# Edita .env.local con tu API key
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000)

---

## Obtener API Key de Anthropic

1. Ve a [console.anthropic.com](https://console.anthropic.com)
2. API Keys → Create Key
3. Copia la key y pégala en Vercel como variable de entorno

---

## Estructura del proyecto

```
pm1-app/
├── app/
│   ├── api/chat/route.js   # Proxy seguro a Anthropic API
│   ├── layout.js
│   ├── page.js
│   └── globals.css
├── components/
│   └── PM1App.js           # UI principal
├── lib/
│   └── pm1-engine.js       # Motor psicológico PM1
└── package.json
```
